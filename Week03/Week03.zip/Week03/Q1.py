grades = [85,92,78,95,88]
grades.append(90)
grades.sort()
print(f"Sorted grades: {grades}")
print("Highest grade:", grades[-1])
print("Lowest grade:", grades[0])
print("Length: ", len(grades))



