# Sample Coding Questions 01 Week 01
# Ricardo Alvear
array = [1,4,7,9]
a = 1
b = 2
c = 3
d = 4
e = (a -b) ** (c // d) + (a % c)
temperature = 32.6
formatTemp = "{:.3f}".format(temperature)
print("The temperature tody is:", formatTemp, "degrees Celsius")
userAge = int(input("What is your age? "))
add = userAge + 22
print("Now showing the shop items filtered by age: ", add)